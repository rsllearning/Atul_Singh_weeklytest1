package com.example.finalassignment;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Locale;
import java.util.concurrent.TimeUnit;

public class Final_Activity extends AppCompatActivity {

    TextView textView;
    Button finish,restart;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_final);

        textView = (TextView) findViewById(R.id.textView4);
        finish = (Button) findViewById(R.id.button7);
        restart = (Button) findViewById(R.id.button6);


        Intent intent = getIntent();
        long sd = intent.getExtras().getLong("time");

        long l = 60000-TimeUnit.MILLISECONDS.toMillis(sd);

        String sDuration = String.format(Locale.ENGLISH,"%02d:%02d",TimeUnit.MILLISECONDS.toMinutes(l),TimeUnit.MILLISECONDS.toSeconds(l)-
                TimeUnit.MINUTES.toMinutes(TimeUnit.MILLISECONDS.toMinutes(l)));

        textView.setText(sDuration);


        finish.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finishAffinity();
            }
        });

        restart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent1 = new Intent(getApplicationContext(),MainActivity.class);
                startActivity(intent1);
            }
        });
    }

}