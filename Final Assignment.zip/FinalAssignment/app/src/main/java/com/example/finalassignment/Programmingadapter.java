package com.example.finalassignment;

import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class Programmingadapter extends RecyclerView.Adapter <Programmingadapter.ProgrammingViewHolder> {
    @NonNull
    @Override
    public Programmingadapter.ProgrammingViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        LayoutInflater inflate = LayoutInflater.from(parent.getContext());
        View view = inflate.inflate(R.layout.ewcq,parent,false);


        return new ProgrammingViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull Programmingadapter.ProgrammingViewHolder holder, int position) {

       holder.textView.setText("this");

    }

    @Override
    public int getItemCount() {
        return 10;
    }




    public class ProgrammingViewHolder extends RecyclerView.ViewHolder{

        TextView textView ;
        RelativeLayout parentl;

        public ProgrammingViewHolder(@NonNull View item) {
            super(item);

            textView = (TextView) item.findViewById(R.id.textView6);
            parentl = (RelativeLayout) item.findViewById(R.id.parentl);

            item.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Toast.makeText(item.getContext(), "this ",Toast.LENGTH_SHORT).show();
                     Intent intent = new Intent(item.getContext(),Activity_demo.class);
                    (item.getContext()).startActivity(intent);
                }
            });
        }
    }
}
