package com.example.finalassignment;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.Locale;
import java.util.concurrent.TimeUnit;

public class Questions_activity extends AppCompatActivity {

    TextView textView;
    Button button,submit;
    String sDuration;
    long t =1;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_questions);

        RecyclerView  programmingList = (RecyclerView)  findViewById(R.id.prgraminglist);
        programmingList.setLayoutManager(new LinearLayoutManager(this));
        programmingList.setAdapter(new Programmingadapter());

        textView = (TextView) findViewById(R.id.textView);
        submit = (Button) findViewById(R.id.button5);

        long duration = TimeUnit.MINUTES.toMillis(1);

        new CountDownTimer(duration, 1) {
            @Override
            public void onTick(long l) {

                t=l;
                sDuration = String.format(Locale.ENGLISH,"%02d:%02d",TimeUnit.MILLISECONDS.toMinutes(l),TimeUnit.MILLISECONDS.toSeconds(l)-
                        TimeUnit.MINUTES.toMinutes(TimeUnit.MILLISECONDS.toMinutes(l)));

                       textView.setText(sDuration);
            }

            @Override
            public void onFinish() {

            }
        }.start();



/*
         //moving to next activity
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(),Activity_demo.class) ;
                String name = "Atl singh";
                intent.putExtra("time",t);
               // startActivity(intent);
            }
        });*/


        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(),Final_Activity.class) ;
                String name = "Atl singh";
                intent.putExtra("time",t);
                startActivity(intent);
            }
        });
    }
}