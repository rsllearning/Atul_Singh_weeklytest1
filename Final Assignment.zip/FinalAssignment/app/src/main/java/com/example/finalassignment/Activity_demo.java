package com.example.finalassignment;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Locale;
import java.util.Random;
import java.util.concurrent.TimeUnit;

public class Activity_demo extends AppCompatActivity {

    TextView textView,questions;
    Button op1,op2,op3,op4;
    String sDuration;
    ArrayList <Quizmodel> quizmodellist;
    Random random;

    int currentscore = 0, questionattempted = 1, currentpos;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo);

        textView = (TextView) findViewById(R.id.textView2);
        questions = (TextView) findViewById(R.id.question);
        op1 = (Button) findViewById(R.id.option1);
        op2 = (Button) findViewById(R.id.option2);
        op3 = (Button) findViewById(R.id.option3);
        op4 = (Button) findViewById(R.id.option4);
        quizmodellist = new ArrayList<>();
        random = new Random();
        getquizquestion(quizmodellist);
       currentpos = random.nextInt(quizmodellist.size());
       setDatatoView(currentpos);

  //      getquizquestion(quizmodellist);
        

        //Intent intent = getIntent();
        int sD = 1;

        Toast.makeText(getApplicationContext(),Long.toString(sD),Toast.LENGTH_SHORT).show();


        long duration = TimeUnit.MILLISECONDS.toMillis(sD);

        new CountDownTimer(duration, 1) {
            @Override
            public void onTick(long l) {


                sDuration = String.format(Locale.ENGLISH,"%02d:%02d",TimeUnit.MILLISECONDS.toMinutes(l),TimeUnit.MILLISECONDS.toSeconds(l)-
                        TimeUnit.MINUTES.toMinutes(TimeUnit.MILLISECONDS.toMinutes(l)));

                textView.setText(sDuration);
            }

            @Override
            public void onFinish() {

            }
        }.start();


    }

    private void setDatatoView(int currentpos) {
        questions.setText(quizmodellist.get(currentpos).getQuestion());
        op1.setText(quizmodellist.get(currentpos).getOption1());
        op2.setText(quizmodellist.get(currentpos).getOption2());
        op3.setText(quizmodellist.get(currentpos).getOption3());
        op4.setText(quizmodellist.get(currentpos).getOption4());


    }

    private void getquizquestion(ArrayList <Quizmodel> quizmodellist) {


        quizmodellist.add(new Quizmodel("Apple","Red","Orange","Green","None","Red"));
        quizmodellist.add(new Quizmodel("Milk","Red","Orange","Green","White","White"));
        quizmodellist.add(new Quizmodel("Buffalow","Black","Orange","Green","None","Black"));


    }

}