package com.example.Fragments;

import android.content.Context;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.example.fragment_communication.R;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link Upper#newInstance} factory method to
 * create an instance of this fragment.
 */
public class Upper extends Fragment {




    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment Upper.
     */
    //

    private Button button,button2;
    private EditText autoCompleteTextView;
    private upperlistner listner;
    private TextView tx;
    public  interface upperlistner
    {
        void onInputAsent(CharSequence input);

    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view =  inflater.inflate(R.layout.fragment_upper, container, false);


        button2 = view.findViewById(R.id.button2);
        button = view.findViewById(R.id.button);

        autoCompleteTextView = view.findViewById(R.id.autoCompleteTextView);
        tx=view.findViewById(R.id.view);

        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                           CharSequence input =  autoCompleteTextView.getText();
                           listner.onInputAsent(input);
            }
        });

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                autoCompleteTextView.setText("");
            }
        });




        return view;
    }

    public void updateeditText(CharSequence newText)
    {

        tx.setText(newText);
    }


    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);

        if(context instanceof upperlistner)
        {
            listner= (upperlistner) context;
        }
        else{
            throw new RuntimeException(context.toString()+"kya kar rha he bhai to ye ");
        }
    }


    @Override
    public void onDetach() {
        super.onDetach();
        listner=null;
    }
}