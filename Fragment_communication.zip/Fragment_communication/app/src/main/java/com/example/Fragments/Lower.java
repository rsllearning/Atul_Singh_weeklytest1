package com.example.Fragments;

import android.content.Context;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.example.fragment_communication.R;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link Lower#newInstance} factory method to
 * create an instance of this fragment.
 */
public class Lower extends Fragment {




    private Button button,button2;
    private EditText autoCompleteTextView;
    private lowerlistner listner;
    private TextView ye;

    public  interface lowerlistner
    {
        void onInputBsent(CharSequence input);

    }


    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view =  inflater.inflate(R.layout.fragment_lower, container, false);

        button2 = view.findViewById(R.id.button2);
        button = view.findViewById(R.id.button);
        autoCompleteTextView = view.findViewById(R.id.autoCompleteTextView);
        ye =view.findViewById(R.id.view);

        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                CharSequence input =  autoCompleteTextView.getText();
                listner.onInputBsent(input);
            }
        });


        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                autoCompleteTextView.setText("");
            }
        });

        return view;

        };







    public void updateeditText(CharSequence newText)
    {
        ye.setText(newText);
    }


    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);

        if(context instanceof lowerlistner)
        {
            listner= (lowerlistner) context;
        }
        else{
            throw new RuntimeException(context.toString()+"kya kar rha he bhai to ye ");
        }
    }


    @Override
    public void onDetach() {
        super.onDetach();
        listner=null;
    }

















}