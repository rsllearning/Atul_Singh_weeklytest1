package com.example.fragment_communication;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentTransaction;

import android.os.Bundle;

import com.example.Fragments.Lower;
import com.example.Fragments.Upper;

public class MainActivity extends AppCompatActivity implements Upper.upperlistner,Lower.lowerlistner{

   private Upper upper;
   private Lower lower;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


         upper = new Upper();
        lower = new Lower();
        getSupportFragmentManager().beginTransaction().replace(R.id.upper,upper).replace(R.id.lower,lower).commit();

    };

    @Override
    public void onInputBsent(CharSequence input) {
        upper.updateeditText(input);
    }

    @Override
    public void onInputAsent(CharSequence input) {
         lower.updateeditText(input);
    }
}