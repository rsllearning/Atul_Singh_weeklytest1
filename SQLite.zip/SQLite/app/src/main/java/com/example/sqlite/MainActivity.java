package com.example.sqlite;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText name,username,password1,password2;
    Button register,login;
    DBHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

         name = (EditText) findViewById(R.id.editTextTextPersonName);
         username = (EditText) findViewById(R.id.editTextTextPersonName2);
         password1 = (EditText) findViewById(R.id.editTextTextPersonName3);
         password2 = (EditText) findViewById(R.id.editTextTextPersonName4);
         register = (Button) findViewById(R.id.button);
         login = (Button) findViewById(R.id.button2);
         db = new DBHelper(this);


         register.setOnClickListener(new View.OnClickListener() {
             @Override
             public void onClick(View view) {

                 String uname = username.getText().toString();
                 String pass1 = password1.getText().toString();
                 String pass2 = password2.getText().toString();

                 if(pass1.equals(pass2))
                 {
                     Boolean checkuser = db.insertData(uname,pass1);

                     Toast.makeText(MainActivity.this,Boolean.toString(checkuser),Toast.LENGTH_LONG).show();
                     Intent intent = new Intent(getApplicationContext(),Home_activity.class);
                     startActivity(intent);
                 }

             }
         });


         login.setOnClickListener(new View.OnClickListener() {
             @Override
             public void onClick(View view) {

                 Intent intent = new Intent(getApplicationContext(),login.class);
                 startActivity(intent);
             }
         });

    }
}