package com.example.frag.fragments;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Bundle;

import androidx.annotation.RequiresApi;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.frag.R;

import org.w3c.dom.Text;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link battery#newInstance} factory method to
 * create an instance of this fragment.
 */
public class battery extends Fragment {


    public battery() {
        // Required empty public constructor
    }


     TextView bat;
    int view = R.layout.fragment_battery;



   ;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view =  inflater.inflate(R.layout.fragment_battery, container, false);

        TextView bat = (TextView) view.findViewById(R.id.bat);
        BatteryManager bm = (BatteryManager) getContext().getSystemService(Context.BATTERY_SERVICE);

        if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.LOLLIPOP)
        {
            int percentage = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY);
            bat.setText("Battery percentage is "+percentage+"%");
        }


        return view;
    }
}