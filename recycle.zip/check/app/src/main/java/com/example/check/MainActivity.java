package com.example.check;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        RecyclerView programmingList = (RecyclerView)  findViewById(R.id.progamminglist);
        programmingList.setLayoutManager(new LinearLayoutManager(this));
        String[] s = {"Atul","Ram","Shayam","Radhe","Dude","Man","Radhe","Dharmveer","Deepak","Atul","Ram","Shayam","Radhe","Dude","Man","Radhe","Dharmveer","Deepak"};
        String[] k = {"1","15","61","25","25","22","11","13","25","22","11","52","25","21","19","1","15","61","25","25","22","11","13","25","22","11","52","25","21","19"};
        String[] j = {"11","12","13","14","15","16","17","1","15","61","25","25","22","11","13","25","22","11","52","25","21","19","1","15","61","25","25","22","11","13"};
        programmingList.setAdapter(new Programmingaddapter(s,k,j));

    }
}