package com.example.check;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

public class Programmingaddapter extends RecyclerView.Adapter<Programmingaddapter.ProgrammingViewHolder> {

    private  String[] datan;
    private  String[] datac;
    private  String[] dataf;


    public  Programmingaddapter(String dat[],String nag[],String ji[])
    {
          this.datan=dat;
          this.datac=nag;
          this.dataf=ji;
     }


    @Override
    public int getItemViewType(int position) {
        // Just as an example, return 0 or 2 depending on position
        // Note that unlike in ListView adapters, types don't have to be contiguous
        int val = position%3;

        if(val==0)
            return  0;
        return 1;
    }



    @NonNull
    @Override
    public ProgrammingViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        LayoutInflater inflate = LayoutInflater.from(parent.getContext());
        View view1 = inflate.inflate(R.layout.list_items_view, parent, false);
        View view2 = inflate.inflate(R.layout.list_items_view2, parent, false);


        switch (viewType) {
            case 0:
                       view1.setOnClickListener(new View.OnClickListener() {
                           @Override
                           public void onClick(View view) {

                           }
                       });
                       return new ProgrammingViewHolder(view1);

            case 1:    return  new ProgrammingViewHolder(view2);
        }
        return  new ProgrammingViewHolder(view2);
    }

    @Override
    public void onBindViewHolder(@NonNull ProgrammingViewHolder holder, int position) {
            String title = datan[position];
      //  Toast.makeText(holder.itemView.getContext(),title,Toast.LENGTH_LONG).show();

        holder.name.setText(title);
        holder.contributions.setText(datac[position]);
        holder.followers.setText(dataf[position]);


    }

    @Override
    public int getItemCount() {
        return datan.length;
    }

    public  class  ProgrammingViewHolder extends RecyclerView.ViewHolder{
        TextView name,contributions,followers;
       //  CardView mcardView;

        public  ProgrammingViewHolder(View items)
       {
           super(items);

              name = (TextView) items.findViewById(R.id.name);
           contributions = (TextView) items.findViewById(R.id.contribution);
            followers = (TextView) items.findViewById(R.id.followers);


            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    int pos = getAbsoluteAdapterPosition();
                    int val = pos%3;
                    String P = "Type#";

                    if(val==0)
                        P=P+"a";
                    else
                        P=P+"b";

                    Toast.makeText(itemView.getContext(),P+":"+"Followers:"+dataf[pos]+", Contributions: "+datac[pos],Toast.LENGTH_LONG).show();

                }
            });

       }

   }




}
