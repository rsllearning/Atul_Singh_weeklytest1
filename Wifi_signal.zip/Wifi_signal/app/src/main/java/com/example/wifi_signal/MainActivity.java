package com.example.wifi_signal;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

      int cnt = 0;

      public  MainActivity()
      {
           this.cnt=0;
      }




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ImageButton pos = (ImageButton) findViewById(R.id.imgb);
        ImageButton neg = (ImageButton) findViewById(R.id.button2);
        ImageButton mute = (ImageButton) findViewById(R.id.mute);
        ImageView im = (ImageView) findViewById(R.id.mam);


        pos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                     ++cnt;
                int val = cnt;

                switch (val)
                {
                    case 0:  im.setImageResource(R.drawable.signal0);
                              break;
                    case 1:  im.setImageResource(R.drawable.signal1);
                              break;
                    case 2:  im.setImageResource(R.drawable.signal2);
                               break;
                    case 3:  im.setImageResource(R.drawable.signal3);
                              break;
                    case 4:  im.setImageResource(R.drawable.signal4);
                              break;

                }

                     //      im.setImageDrawable(getResources().getDrawable(R.drawable.signal2));
              //  Toast.makeText(MainActivity.this,Integer.toString(cnt),Toast.LENGTH_LONG).show();
            }
        });

        neg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                --cnt;

                int val = cnt;

                switch (val)
                {
                    case 0:  im.setImageResource(R.drawable.signal0);
                        break;
                    case 1:  im.setImageResource(R.drawable.signal1);
                        break;
                    case 2:  im.setImageResource(R.drawable.signal2);
                        break;
                    case 3:  im.setImageResource(R.drawable.signal3);
                        break;
                    case 4:  im.setImageResource(R.drawable.signal4);
                        break;

                }


             //   Toast.makeText(MainActivity.this,Integer.toString(cnt),Toast.LENGTH_LONG).show();

            }
        });


        mute.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                im.setImageResource(R.drawable.signal5);

            }
        });
    }


}